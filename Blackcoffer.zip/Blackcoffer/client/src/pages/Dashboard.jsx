import React, { useEffect, useState } from "react";
import { useContext } from "react";
import { dataContext } from "../context/myContext";
import {
  options,
  optionsPie,
  optionsPieLikelihood,
  optionsPiRelevanceRegion,
  intensityBasedOnRegion,
  optionsPiRelevance,
} from "../chartData";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { Pie } from "react-chartjs-2";
import { Select } from "antd";
const { Option } = Select;
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const Dashboard = () => {
  const [intensityYear, setIntensityYear] = useState([]);

  const [lineChart, setLineChart] = useState({});
  const [pieChart1, setPieChart1] = useState({});
  const [pieChart2, setPieChart2] = useState({});
  const [pieChart3, setPieChart3] = useState({});
  const [pieChart4, setPieChart4] = useState({});
  const [pieChart5, setPieChart5] = useState({});

  const {
    HandleFetchTopic,
    topic,
    HandleFetchSector,
    sector,
    HandleFetchRegionTopic,
    region,
    HandleFetchRegionBySectorTopic,
    regionSector,
    HandleFetchIntensityLineChart,
    intensity,
    loader,
    HandleFetchAllData,
    dashboard,
    handleFetchCountryIntensity,
  } = useContext(dataContext);
  const [filterCountryTopic, setfilterCountryTopic] = useState([]);
  const [filterCountrySector, setfilterCountrySector] = useState([]);

  const [filterRegionTopic, setfilterRegionTopic] = useState([]);
  const [filterRegionSector, setfilterRegionSector] = useState([]);
  const [searchByll, setSearchByAll] = useState();
  const [countryName, setCountryName] = useState("");
  const [regionName, setRegionName] = useState("");
  const [topicName, setTopicName] = useState("");
  const [sectorName, setSectorName] = useState("");
  const [startYearName, setStartYearName] = useState("");
  const [endYearName, setEndYearName] = useState("");
  const [intensityName, setIntensityName] = useState("");
  const [relevanceName, setRelevanceName] = useState("");
  const [likelihoodName, setLikelihoodName] = useState("");

  useEffect(() => {
    const fetchTopic = async () => {
      await HandleFetchTopic();
      await HandleFetchSector();
      await HandleFetchRegionTopic();
      await HandleFetchRegionBySectorTopic();
      await HandleFetchAllData();
      console.log("dashboard", dashboard);
    };
    fetchTopic();
  }, []);

  useEffect(() => {
    const fetchIntensity = async () => {
      const data = await HandleFetchIntensityLineChart();
      if (!data) return;
      const intenSityYearData = data?.map(({ intensity }) => {
        return intensity;
      });
      const likelihoodYearData = data?.map(({ likelihood }) => {
        return likelihood;
      });
      const relevanceYearData = data?.map(({ relevance }) => {
        return relevance;
      });

      const labels = data?.map(({ start_year, end_year }) => {
        return parseInt(end_year, 10) - parseInt(start_year, 10);
      });
      console.log(
        intenSityYearData.slice(0, 10),
        likelihoodYearData.slice(0, 10)
      );
      const lineData = {
        labels: labels,
        datasets: [
          {
            label: "intensity",
            data: intenSityYearData,
            borderColor: "rgb(131,105,249)",
            backgroundColor: "rgb(131,105,241)",
            tension: 0.1,
          },
          {
            label: "likelihood",
            data: likelihoodYearData,
            borderColor: "rgb(255,189,31)",
            backgroundColor: "rgba(255,189,31,0.7)",
          },
          {
            label: "relevance",
            data: relevanceYearData,
            borderColor: "rgb(246,159,169)",
            backgroundColor: "rgba(246,159,169,0.6)",
          },
        ],
      };
      setLineChart(lineData);
    };
    fetchIntensity();
  }, []);

  useEffect(() => {
    const fetchCountryIntensity = async () => {
      const data = await handleFetchCountryIntensity();
      const country = data?.map((c, i) => {
        return c.country;
      });
      const intensity = data?.map((c, i) => {
        return c.intensity;
      });
      const relevance = data?.map((c, i) => {
        return c.relevance;
      });
      const region = data?.map((c, i) => {
        return c.region;
      });
      const likelihood = data?.map((c, i) => {
        return c.likelihood;
      });

      const dataStatus = {
        labels: country.slice(0, 10),
        datasets: [
          {
            label: "Intensity",
            data: intensity.slice(0, 10),
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(255, 206, 86, 0.2)",
              "rgba(75, 192, 192, 0.2)",
            ],
            borderColor: [
              "rgba(255, 99, 132, 1)",
              "rgba(54, 162, 235, 1)",
              "rgba(255, 206, 86, 1)",
              "rgba(75, 192, 192, 1)",
            ],
            borderWidth: 1,
          },
        ],
      };
      const LikelihoodLikelihood = {
        labels: country.slice(0, 5),
        datasets: [
          {
            label: "Relevance",
            data: relevance.slice(0, 5),
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(255, 206, 86, 0.2)",
              "rgba(75, 192, 192, 0.2)",
            ],
            borderColor: [
              "rgba(255, 99, 132, 1)",
              "rgba(54, 162, 235, 1)",
              "rgba(255, 206, 86, 1)",
              "rgba(75, 192, 192, 1)",
            ],
            borderWidth: 1,
          },
        ],
      };
      const LikelihoodRelevance = {
        labels: country.slice(0, 5),
        datasets: [
          {
            label: "Likelihood",
            data: likelihood.slice(0, 5),
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(255, 206, 86, 0.2)",
              "rgba(75, 192, 192, 0.2)",
            ],
            borderColor: [
              "rgba(255, 99, 132, 1)",
              "rgba(54, 162, 235, 1)",
              "rgba(255, 206, 86, 1)",
              "rgba(75, 192, 192, 1)",
            ],
            borderWidth: 1,
          },
        ],
      };
      const LikelihoodRelevanceRegion = {
        labels: region.slice(0, 5),
        datasets: [
          {
            label: "Intensity",
            data: intensity.slice(0, 5),
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(255, 206, 86, 0.2)",
              "rgba(75, 192, 192, 0.2)",
            ],
            borderColor: [
              "rgba(255, 99, 132, 1)",
              "rgba(54, 162, 235, 1)",
              "rgba(255, 206, 86, 1)",
              "rgba(75, 192, 192, 1)",
            ],
            borderWidth: 1,
          },
        ],
      };

      const intensityBasedOnRegionData = {
        labels: region.slice(0, 5),
        datasets: [
          {
            label: "Relevance",
            data: relevance.slice(0, 5),
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)",
              "rgba(255, 206, 86, 0.2)",
              "rgba(75, 192, 192, 0.2)",
            ],
            borderColor: [
              "rgba(255, 99, 132, 1)",
              "rgba(54, 162, 235, 1)",
              "rgba(255, 206, 86, 1)",
              "rgba(75, 192, 192, 1)",
            ],
            borderWidth: 1,
          },
        ],
      };
      setPieChart1(dataStatus);
      setPieChart2(LikelihoodLikelihood);
      setPieChart3(LikelihoodRelevance);
      setPieChart4(LikelihoodRelevanceRegion);
      setPieChart5(intensityBasedOnRegionData);

      console.log(intensity, "c/I");
    };
    fetchCountryIntensity();
  }, []);
  const handleSearchByCountryTopic = (e) => {
    const x = e.target.value.toLowerCase();
    const CountryTopic = topic.filter(
      (t) =>
        t.country.toLowerCase().includes(x) || t.topic.toLowerCase().includes(x)
    );
    setfilterCountryTopic(CountryTopic.slice(0, 10));
    console.log(CountryTopic, "CountryTopic");
  };

  const handleSearchByCountrySector = (e) => {
    const x = e.target.value.toLowerCase();
    const CountryTopic = sector.filter(
      (t) =>
        t.country.toLowerCase().includes(x) ||
        t.sector.toLowerCase().includes(x)
    );
    setfilterCountrySector(CountryTopic.slice(0, 10));
    console.log(CountryTopic, "CountryTopic");
  };

  const handleSearchByRegionTopic = (e) => {
    const x = e.target.value.toLowerCase();
    console.log(region);
    const CountryTopic = region.filter(
      (t) =>
        t?.region.toLowerCase().includes(x) || t.topic.toLowerCase().includes(x)
    );
    setfilterRegionTopic(CountryTopic.slice(0, 10));
    console.log(CountryTopic, "CountryTopic");
  };

  const handleSearchByRegionSector = (e) => {
    const x = e.target.value.toLowerCase();
    const CountryTopic = regionSector.filter(
      (t) =>
        t?.region.toLowerCase().includes(x) ||
        t.sector.toLowerCase().includes(x)
    );
    setfilterRegionSector(CountryTopic.slice(0, 10));
    console.log(CountryTopic, "CountryTopic");
  };
  const handleSearchAll = (e) => {
    const x = e.target.value.toLowerCase();
    const CountryTopic = dashboard.filter(
      (t) =>
        t?.region.toLowerCase().includes(x) ||
        t.sector.toLowerCase().includes(x) ||
        t?.country.toLowerCase().includes(x) ||
        t?.start_year.toLowerCase().includes(x) ||
        t?.end_year.toLowerCase().includes(x) ||
        t.relevance === Number(e.target.value) ||
        t?.likelihood === Number(e.target.value) ||
        t.intensity === Number(e.target.value) ||
        t.topic.toLowerCase().includes(x)
    );
    setSearchByAll(CountryTopic);
    console.log(CountryTopic, "CountryTopic");
  };
  const AllFilter = searchByll?.length > 0 ? searchByll : dashboard;

  const handleSingleFilter = () => {
    console.log(
      countryName,
      regionName,
      topicName,
      sectorName,
      likelihoodName,
      intensityName,
      relevanceName,
      startYearName,
      endYearName
    );

    let singleFilter = AllFilter;

    if (countryName) {
      singleFilter = singleFilter?.filter((s) => s.country === countryName);
    }

    if (regionName) {
      singleFilter = singleFilter?.filter((s) => s.region === regionName);
    }

    if (topicName) {
      singleFilter = singleFilter?.filter((s) => s.topic === topicName);
    }

    if (sectorName) {
      singleFilter = singleFilter?.filter((s) => s.sector === sectorName);
    }

    if (likelihoodName) {
      singleFilter = singleFilter?.filter(
        (s) => s.likelihood === likelihoodName
      );
    }

    if (intensityName) {
      singleFilter = singleFilter?.filter((s) => s.intensity === intensityName);
    }

    if (relevanceName) {
      singleFilter = singleFilter?.filter((s) => s.relevance === relevanceName);
    }

    if (startYearName) {
      singleFilter = singleFilter?.filter(
        (s) => s.start_year === startYearName
      );
    }

    if (endYearName) {
      singleFilter = singleFilter?.filter((s) => s.end_year === endYearName);
    }

    setSearchByAll(singleFilter);
    console.log(singleFilter, "singleFilter");
  };
  const handleClearSingle = () => {
    setSearchByAll(dashboard);
    // setCountryName("");
    // setRegionName("");
    // setTopicName("");
    // setSectorName("");
    // setStartYearName("");
    // setEndYearName("");
    // setIntensityName("");
    // setLikelihoodName("");
    // setRelevanceName("");
  };
  if (loader) {
    return <h1>Loader...</h1>;
  }
  return (
    <div className="dashboard my-4">
      <div className="container-fluid">
        <div className="parentDashboard">
          <div className="row">
            <div className="col-md-7 p-2">
              <div className="commonGraph heightSet p-2">
                {Object.keys(lineChart).length > 0 && (
                  <Line options={options} data={lineChart} />
                )}
              </div>
            </div>
            <div className="col-md-5 p-2">
              <div className="commonGraph heightSet p-2">
                {Object.keys(pieChart1).length > 0 && (
                  <Pie
                    data={pieChart1}
                    options={optionsPie}
                    className="w-75 m-auto h-100"
                  />
                )}
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-3">
            <div className="commonGraph">
              {Object.keys(pieChart2).length > 0 && (
                <Pie data={pieChart2} options={optionsPieLikelihood} />
              )}
            </div>
          </div>
          <div className="col-md-3">
            <div className="commonGraph">
              {Object.keys(pieChart3).length > 0 && (
                <Pie data={pieChart3} options={optionsPiRelevance} />
              )}
            </div>
          </div>
          <div className="col-md-3">
            <div className="commonGraph">
              {Object.keys(pieChart4).length > 0 && (
                <Pie data={pieChart4} options={optionsPiRelevanceRegion} />
              )}
            </div>
          </div>
          <div className="col-md-3">
            <div className="commonGraph">
              {Object.keys(pieChart5).length > 0 && (
                <Pie data={pieChart5} options={intensityBasedOnRegion} />
              )}
            </div>
          </div>
        </div>
        <div className="row my-2">
          <div className="col-md-6">
            <div className="commonGraph my-2 p-2 filterTableData">
              <div>
                <h5>Country Data By Topic</h5>
              </div>
              <div>
                <input
                  type="text"
                  class="form-control"
                  placeholder="Country/Topic"
                  onChange={handleSearchByCountryTopic}
                ></input>
              </div>
            </div>
            <div className="commonGraph">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">s.no</th>
                    <th scope="col">Country</th>
                    <th scope="col">Topic</th>
                  </tr>
                </thead>
                <tbody>
                  {filterCountryTopic.length > 0
                    ? filterCountryTopic?.map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.country}</td>
                          <td>{t.topic}</td>
                        </tr>
                      ))
                    : topic.slice(0, 10)?.map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.country}</td>
                          <td>{t.topic}</td>
                        </tr>
                      ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="col-md-6">
            <div className="commonGraph my-2 p-2 filterTableData">
              <div>
                <h5>Country Data By Sector</h5>
              </div>
              <div>
                <input
                  type="text"
                  class="form-control"
                  placeholder="Country/Sector"
                  onChange={handleSearchByCountrySector}
                ></input>
              </div>
            </div>

            <div className="commonGraph">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">s.no</th>
                    <th scope="col">Country</th>
                    <th scope="col">Sector</th>
                  </tr>
                </thead>
                <tbody>
                  {filterCountrySector.length > 0
                    ? filterCountrySector?.map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.country}</td>
                          <td>{t.sector}</td>
                        </tr>
                      ))
                    : sector.slice(0, 10)?.map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.country}</td>
                          <td>{t.sector}</td>
                        </tr>
                      ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="row my-2">
          <div className="col-md-6">
            <div className="commonGraph my-2 p-2 filterTableData">
              <div>
                <h5>Region Data By Topic</h5>
              </div>
              <div>
                <div>
                  <input
                    type="text"
                    class="form-control"
                    placeholder="Region/Topic"
                    onChange={handleSearchByRegionTopic}
                  ></input>
                </div>
              </div>
            </div>
            <div className="commonGraph">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">s.no</th>
                    <th scope="col">Region</th>
                    <th scope="col">Topic</th>
                  </tr>
                </thead>
                <tbody>
                  {filterRegionTopic.length > 0
                    ? filterCountrySector.map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.region}</td>
                          <td>{t.topic}</td>
                        </tr>
                      ))
                    : region.slice(0, 10).map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.region}</td>
                          <td>{t.topic}</td>
                        </tr>
                      ))}
                </tbody>
              </table>
            </div>
          </div>
          <div className="col-md-6">
            <div className="commonGraph my-2 p-2 filterTableData">
              <div>
                <h5>Region Data By Sector</h5>
              </div>
              <div>
                <input
                  type="text"
                  class="form-control"
                  placeholder="Region/Sector"
                  onChange={handleSearchByRegionSector}
                ></input>
              </div>
            </div>

            <div className="commonGraph">
              <table class="table m-0 p-0 g-0">
                <thead>
                  <tr>
                    <th scope="col">s.no</th>
                    <th scope="col">Region</th>
                    <th scope="col">Sector</th>
                  </tr>
                </thead>
                <tbody>
                  {filterRegionSector.length > 0
                    ? filterRegionSector.map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.region}</td>
                          <td>{t.sector}</td>
                        </tr>
                      ))
                    : regionSector.slice(0, 10).map((t, i) => (
                        <tr
                          className={
                            i % 2 === 0 ? "table-danger" : "table-primary"
                          }
                        >
                          <th scope="row">{i + 1}</th>
                          <td>{t.region}</td>
                          <td>{t.sector}</td>
                        </tr>
                      ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="row my-2">
          <div className="col-12">
            <div className="commonGraph my-2 p-2 filterTableData">
              <div>
                <h5>Region Data By Topic</h5>
              </div>
              <div></div>
            </div>
            <div className="commonGraph">
              <div className="commonGraph  p-2 pb-5 " id="allFilter">
                <div>
                  <div>
                    <h6>Search By Any Name</h6>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="search by any name"
                      onChange={handleSearchAll}
                    ></input>
                  </div>
                  <div className="my-1">
                    <h6>Single Search</h6>
                    <div className="singleFilter">
                      <div>
                        <Select
                          bordered={false}
                          placeholder="Select a Country"
                          size="large"
                          showSearch
                          className="form-select mb-3"
                          onChange={(value) => {
                            setCountryName(value);
                          }}
                        >
                          {dashboard?.map((c) => (
                            <Option key={c._id} value={c.country}>
                              {c.country}
                            </Option>
                          ))}
                        </Select>
                      </div>
                      <div>
                        <Select
                          bordered={false}
                          placeholder="Select a Region"
                          size="large"
                          showSearch
                          className="form-select mb-3"
                          onChange={(value) => {
                            setRegionName(value);
                          }}
                        >
                          {dashboard?.map((c) => (
                            <Option key={c._id} value={c.region}>
                              {c.region}
                            </Option>
                          ))}
                        </Select>
                      </div>
                      <div>
                        <Select
                          bordered={false}
                          placeholder="Select a Sector"
                          size="large"
                          showSearch
                          className="form-select mb-3"
                          onChange={(value) => {
                            setSectorName(value);
                          }}
                        >
                          {dashboard?.map((c) => (
                            <Option key={c._id} value={c.sector}>
                              {c.sector}
                            </Option>
                          ))}
                        </Select>
                      </div>
                      <div>
                        <Select
                          bordered={false}
                          placeholder="Select a Topic"
                          size="large"
                          showSearch
                          className="form-select mb-3"
                          onChange={(value) => {
                            setTopicName(value);
                          }}
                        >
                          {dashboard?.map((c) => (
                            <Option key={c._id} value={c.topic}>
                              {c.topic}
                            </Option>
                          ))}
                        </Select>
                      </div>
                      <div>
                        <Select
                          bordered={false}
                          placeholder="Select a Start Year"
                          size="large"
                          showSearch
                          className="form-select mb-3"
                          onChange={(value) => {
                            setStartYearName(value);
                          }}
                        >
                          {dashboard?.map((c) => (
                            <Option key={c._id} value={c.start_year}>
                              {c.start_year}
                            </Option>
                          ))}
                        </Select>
                      </div>
                      <div>
                        <Select
                          bordered={false}
                          placeholder="Select a Country"
                          size="large"
                          showSearch
                          className="form-select mb-3"
                          onChange={(value) => {
                            setEndYearName(value);
                          }}
                        >
                          {dashboard?.map((c) => (
                            <Option key={c._id} value={c.end_year}>
                              {c.end_year}
                            </Option>
                          ))}
                        </Select>
                      </div>
                      <div className="singleFilter2">
                        <div className="">
                          <Select
                            bordered={false}
                            placeholder="Select a Intensity"
                            size="large"
                            showSearch
                            className="form-select mb-3"
                            onChange={(value) => {
                              setIntensityName(value);
                            }}
                          >
                            {dashboard?.map((c) => (
                              <Option key={c._id} value={c.intensity}>
                                {c.intensity}
                              </Option>
                            ))}
                          </Select>
                        </div>
                        <div className="mx-2">
                          <Select
                            bordered={false}
                            placeholder="Select a Likelihood"
                            size="large"
                            showSearch
                            className="form-select mb-3"
                            onChange={(value) => {
                              setLikelihoodName(value);
                            }}
                          >
                            {dashboard?.map((c) => (
                              <Option key={c._id} value={c.likelihood}>
                                {c.likelihood}
                              </Option>
                            ))}
                          </Select>
                        </div>
                        <div className="mx-2">
                          <Select
                            bordered={false}
                            placeholder="Select a Relevance"
                            size="large"
                            showSearch
                            className="form-select mb-3"
                            onChange={(value) => {
                              setRelevanceName(value);
                            }}
                          >
                            {dashboard?.map((c) => (
                              <Option key={c._id} value={c.relevance}>
                                {c.relevance}
                              </Option>
                            ))}
                          </Select>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <button
                        className="mx-2 singleFilterSubmit btn btn-danger rounded"
                        onClick={handleSingleFilter}
                      >
                        Submit
                      </button>
                      <button
                        className="mx-2 singleFilterSubmit btn btn-danger rounded"
                        onClick={handleClearSingle}
                      >
                        Clear
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">s.no</th>
                    <th scope="col">country</th>
                    <th scope="col">region</th>
                    <th scope="col">start_year</th>

                    <th scope="col">end_year</th>

                    <th scope="col">topic</th>

                    <th scope="col">sector</th>
                    <th scope="col">relevance</th>

                    <th scope="col">likelihood</th>

                    <th scope="col">intensity</th>
                  </tr>
                </thead>
                <tbody>
                  {AllFilter.map((t, i) => (
                    <tr
                      className={i % 2 === 0 ? "table-danger" : "table-primary"}
                    >
                      <th scope="row">{i + 1}</th>
                      <td>{t.country}</td>
                      <td>{t.region}</td>
                      <td>{t.start_year}</td>

                      <td>{t.end_year}</td>

                      <td>{t.topic}</td>
                      <td>{t.sector}</td>
                      <td>{t.relevance}</td>

                      <td>{t.likelihood}</td>

                      <td>{t.intensity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
