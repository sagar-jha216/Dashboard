import React from "react";
import { Link } from "react-router-dom";
const Header = () => {
  return (
    <>
      <div className="container-fluid mainHeader">
        <div className="d-flex justify-content-between align-items-center">
          <div className="logo">
            <img
              src="https://blackcoffer.com/wp-content/uploads/2023/10/Black-720x172-4.png"
              alt="logo"
            />
          </div>
          <div className="d-flex justify-content-end align-items-center header">
            <div>
              <span>Dashboard</span>
            </div>
            <div>
              <span>BlackCoffer</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;
