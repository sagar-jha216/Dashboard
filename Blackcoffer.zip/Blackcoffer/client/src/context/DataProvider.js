import React, { useEffect, useState } from "react";
import { dataContext } from "./myContext";
import axios from "axios";
const DataProvider = ({ children }) => {
  const [topic, setTopic] = useState([]);
  const [sector, setSector] = useState([]);
  const [region, SetRegion] = useState([]);
  const [regionSector, setRegionSector] = useState([]);
  const [intensity, setIntensity] = useState([]);
  const [dashboard, setDashboard] = useState([]);

  const [loader, setLoader] = useState(false);
  const HandleFetchTopic = async () => {
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_API_KEY}/countrytopic`
      );
      if (data.success) {
        // console.log(data?.data);
        setTopic(data?.data);
      }
    } catch (e) {
      console.log(e);
    }
  };
  const HandleFetchSector = async () => {
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_API_KEY}/countrysector`
      );
      if (data.success) {
        // console.log(data?.data);
        setSector(data?.data);
      }
    } catch (e) {
      console.log(e);
    }
  };
  const HandleFetchRegionTopic = async () => {
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_API_KEY}/regiontopic`
      );
      if (data.success) {
        // console.log(data?.data);
        SetRegion(data?.data);
      }
    } catch (e) {
      console.log(e);
    }
  };
  const HandleFetchRegionBySectorTopic = async () => {
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_API_KEY}/regionsector`
      );
      if (data.success) {
        // console.log(data?.data);
        setRegionSector(data?.data);
      }
    } catch (e) {
      console.log(e);
    }
  };

  const HandleFetchIntensityLineChart = async () => {
    setLoader(true);
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_API_KEY}/alldata`
      );
      if (data.success) {
        setLoader(false);
        // console.log(data?.data);
        setIntensity(data?.data);

        return data?.data;
      }
    } catch (e) {
      setLoader(false);

      console.log(e);
    }
  };
  const HandleFetchAllData = async () => {
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_API_KEY}/dashboard`
      );
      if (data.success) {
        setLoader(false);
        // console.log(data?.data);
        setDashboard(data?.data);

        return data?.data;
      }
    } catch (e) {
      setLoader(false);

      console.log(e);
    }
  };
  const handleFetchCountryIntensity = async () => {
    try {
      const { data } = await axios.get(
        `${process.env.REACT_APP_API_KEY}/intensitycountry`
      );
      if (data.success) {
        return data?.data;
      }
    } catch (e) {
      console.log(e);
    }
  };
  return (
    <dataContext.Provider
      value={{
        HandleFetchTopic,
        topic,
        HandleFetchSector,
        setSector,
        sector,
        HandleFetchRegionTopic,
        region,
        HandleFetchRegionBySectorTopic,
        regionSector,
        HandleFetchIntensityLineChart,
        intensity,
        loader,
        HandleFetchAllData,
        dashboard,
        handleFetchCountryIntensity,
      }}
    >
      {children}
    </dataContext.Provider>
  );
};

export default DataProvider;
