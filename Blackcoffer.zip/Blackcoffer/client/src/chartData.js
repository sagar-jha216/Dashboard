export const options = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: true,
      text: "Yearly Report",
    },
  },
};
export const optionsPie = {
  responsive: true,
  plugins: {
    legend: {
      position: "right",
      font: {
        size: 6,
        weight: "bold",
      },
    },

    title: {
      display: true,
      text: "Intensity Based On Country",
    },
  },
};
export const optionsPieLikelihood = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: true,
      text: "Relevance Based On Country",
    },
  },
};
export const optionsPiRelevanceRegion = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: true,
      text: "Intensity Based On Region",
    },
  },
};
export const intensityBasedOnRegion = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: true,

      text: "Relevance Based On Region",
    },
  },
};

export const optionsPiRelevance = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: true,
      text: "Likelihood Based On Country",
    },
  },
};
