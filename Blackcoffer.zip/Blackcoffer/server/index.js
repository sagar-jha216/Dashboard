import express from "express";
import { config } from "dotenv";
import colors from "colors";
import connectDB from "./config/db.js";
import cors from "cors";
import dashboardRoutes from "./Routes/dashboard.js";
config({
  path: "./config/config.env",
});
connectDB();

const app = express();

// middleware
app.use(express.json());
app.use(cors());
// routes
app.use("/api/v1", dashboardRoutes);

app.get("/", (req, res) => {
  res.send(
    `<div style="display: flex; justify-content: center; align-items: center; background-color: black; color: white; height: 100vh;"><h1>Welcome to Blackcoffer</h1></div>`
  );
});

app.listen(process.env.PORT, () => {
  console.log(`server is connecting at ${process.env.PORT}`.bgCyan.white);
});
