import { Dashboard } from "../Model/dashboard.js";
export const allDataController = async (req, res) => {
  try {
    const dashboard = await Dashboard.find(
      {
        region: { $ne: null, $ne: "" },
        topic: { $ne: null, $ne: "" },
        end_year: { $ne: null, $ne: "" },
        intensity: { $ne: null, $ne: "" },
        sector: { $ne: null, $ne: "" },
        country: { $ne: null, $ne: "" },
        start_year: { $ne: null, $ne: "" },
        relevance: { $ne: null, $ne: "" },
        title: { $ne: null, $ne: "" },
        likelihood: { $ne: null, $ne: "" },
      },
      {
        region: 1,
        topic: 1,
        end_year: 1,
        sector: 1,
        intensity: 1,
        likelihood: 1,
        relevance: 1,
        start_year: 1,
        country: 1,
        title: 1,
      }
    );
    if (!dashboard) {
      res.status(404).send({
        success: false,
        message: "not found",
      });
    }
    console.log(dashboard);
    res.status(200).send({
      success: true,
      data: dashboard,
    });
  } catch (e) {
    res.status(501).send({
      success: false,
      message: "Internal server error",
      e,
    });
  }
};
export const allCountryTopicController = async (req, res) => {
  try {
    const countryTopic = await Dashboard.find(
      {
        country: { $ne: null, $ne: "" },
        topic: { $ne: null, $ne: "" },
      },
      { country: 1, topic: 1 }
    );
    if (!countryTopic) {
      res.status(404).send({
        success: false,
        message: "not found",
      });
    }
    res.send({
      success: true,
      data: countryTopic,
    });
  } catch (e) {
    res.status(501).send({
      success: false,
      message: "Internal server error",
      e,
    });
  }
};
export const allCountrySectorController = async (req, res) => {
  try {
    const countrySector = await Dashboard.find(
      {
        country: { $ne: null, $ne: "" },
        sector: { $ne: null, $ne: "" },
      },
      { country: 1, sector: 1 }
    );
    if (!countrySector) {
      res.status(404).send({
        success: false,
        message: "not found",
      });
    }
    res.send({
      success: true,
      data: countrySector,
    });
  } catch (e) {
    res.status(501).send({
      success: false,
      message: "Internal server error",
      e,
    });
  }
};
export const allRegionTopicController = async (req, res) => {
  try {
    const RegionTopic = await Dashboard.find(
      {
        region: { $ne: null, $ne: "" },
        topic: { $ne: null, $ne: "" },
      },
      { region: 1, topic: 1 }
    );
    if (!RegionTopic) {
      res.status(404).send({
        success: false,
        message: "not found",
      });
    }
    res.send({
      success: true,
      data: RegionTopic,
    });
  } catch (e) {
    res.status(501).send({
      success: false,
      message: "Internal server error",
      e,
    });
  }
};
export const allRegionSectorController = async (req, res) => {
  try {
    const regionSector = await Dashboard.find(
      {
        region: { $ne: null, $ne: "" },
        sector: { $ne: null, $ne: "" },
      },
      { sector: 1, region: 1 }
    );
    if (!regionSector) {
      res.status(404).send({
        success: false,
        message: "not found",
      });
    }
    res.send({
      success: true,
      data: regionSector,
    });
  } catch (e) {
    res.status(501).send({
      success: false,
      message: "Internal server error",
      e,
    });
  }
};
export const allCombinationController = async (req, res) => {
  try {
    const regionSector = await Dashboard.find(
      {
        start_year: { $ne: null, $ne: "" },
        end_year: { $ne: null, $ne: "" },
        intensity: { $ne: null, $ne: "" },
        relevance: { $ne: null, $ne: "" },
        likelihood: { $ne: null, $ne: "" },
      },
      { start_year: 1, end_year: 1, intensity: 1, relevance: 1, likelihood: 1 }
    );
    if (!regionSector) {
      res.status(404).send({
        success: false,
        message: "not found",
      });
    }
    res.send({
      success: true,
      data: regionSector,
    });
  } catch (e) {
    res.status(501).send({
      success: false,
      message: "Internal server error",
      e,
    });
  }
};

export const intensityCountryController = async (req, res) => {
  try {
    const intensityCountry = await Dashboard.find(
      {
        intensity: { $ne: null, $ne: "" },
        likelihood: { $ne: null, $ne: "" },
        relevance: { $ne: null, $ne: "" },
        country: { $ne: null, $ne: "" },
        region: { $ne: null, $ne: "" },
      },
      { intensity: 1, region: 1, likelihood: 1, relevance: 1, country: 1 }
    );
    if (!intensityCountry) {
      res.status(404).send({
        success: false,
        message: "not found",
      });
    }
    res.status(200).send({
      success: true,
      data: intensityCountry,
    });
  } catch (e) {
    res.status(501).send({
      success: false,
      message: "Internal server error",
      e,
    });
  }
};
