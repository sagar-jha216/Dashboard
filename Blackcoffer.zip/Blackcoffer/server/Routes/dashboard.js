import express from "express";
const router = express.Router();
import {
  allDataController,
  allCountryTopicController,
  allCountrySectorController,
  allRegionTopicController,
  allRegionSectorController,
  allCombinationController,
  intensityCountryController,
} from "../Controller/dashboardController.js";

router.get("/dashboard", allDataController);
router.get("/countrytopic", allCountryTopicController);
router.get("/countrysector", allCountrySectorController);
router.get("/regiontopic", allRegionTopicController);
router.get("/regionsector", allRegionSectorController);
router.get("/alldata", allCombinationController);
router.get("/intensitycountry", intensityCountryController);

export default router;
